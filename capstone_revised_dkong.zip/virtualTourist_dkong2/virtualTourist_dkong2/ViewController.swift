//
//  ViewController.swift
//  virtualTourist_dkong2
//
//  Created by Daniel Kong on 11/20/16.
//  Copyright © 2016 Daniel Kong. All rights reserved.
//

import CoreData
import UIKit

class ViewController: UIViewController {    
    lazy var context: NSManagedObjectContext = {
        return CoreDataStack.sharedInstance().context
    } ()
    
    func showConnectionAlertView(error: String? = "HTTP Errors") {
        dispatch_async(dispatch_get_main_queue(), {
            var alertTitle = ""
            var alertMessage = ""
            switch error! {
            case "Connection timed out":
                alertTitle = error!
                alertMessage = error!
            case "HTTP Errors":
                alertTitle = "No Internet Connection"
                alertMessage = "Connect to the Internet to use this app. We use local data currently."
            case "SOCK Errors":
                alertTitle = "SOCK Error"
                alertMessage = "Connection got refused by SOCK errors."
            default: break
            }
            let alert = UIAlertController(title: alertTitle, message: alertMessage,
                preferredStyle: .Alert)
            alert.addAction(UIAlertAction(title: "Okay", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        })
    }
}

